﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using CodingActivity_TicTacToe_ConsoleGame.Controller;
using System.IO;

namespace CodingActivity_TicTacToe_ConsoleGame
{
    public class ConsoleView
    {
        #region ENUMS

        public enum ViewStateInRound
        {
            RoundEnabled,
            PlayerUsedMaxAttempts,
            PlayerQuit
        }

        public enum ViewStateGame
        {
            MainMenu,
            GamePlay,
            Options,
            CurrentGameStats,
            HistoricStats,
            Quit            
        }

        public enum ViewStateOptions
        {
            OptionsMenu,
            SaveData,
            ClearData,
            ReturnToMenu
        }

        public enum HistoricStatsState
        {
            HistoricStatsMenu,
            HighScores,
            Filtering,
            ReturnToMenu
        }

        public enum PlayerSelectionChoice
        {
            PlayerXFirst,
            PlayerOFirst,
            OppositeOfLastRound,
            ComputerDecided,
            None
        }

        #endregion

        #region FIELDS

        private const int GAMEBOARD_VERTICAL_LOCATION = 4;
        private const int GAMEBOARD_HORIZONTAL_OFFSET = 23;
        private const int GAMEBOARD_CONSOLE_HEIGHT = 7;

        private const int PLAYER_COLOR_CHOICE_SELECTION_BLOCK = 12;

        private const int POSITIONPROMPT_VERTICAL_LOCATION = 12;
        private const int POSITIONPROMPT_HORIZONTAL_LOCATION = 3;

        private const int MENU_PROMPT_VERTICAL_LOCATION = 14;

        private const int MESSAGEBOX_VERTICAL_LOCATION = 15;

        private const int TOP_LEFT_ROW = 3;
        private const int TOP_LEFT_COLUMN = 6;

        private const int NUMBER_OF_MAIN_MENU_CHOICES = 6;
        private const int NUMBER_OF_PLAYER_SELECTION_CHOICES = 4;
        private const int NUMBER_OF_OPTION_CHOICES = 4;
        private const int NUMBER_OF_HISTORIC_STAT_CHOICES = 3;

        // trying to create the equivalent of a const for a reference data type
        private static readonly ConsoleColor[] PLAYER_COLOR_CHOICES = {ConsoleColor.DarkMagenta, ConsoleColor.Red, ConsoleColor.Green,
                                                                        ConsoleColor.Black, ConsoleColor.DarkBlue, ConsoleColor.White };

        private GameboardPosition _inProgressPosition;
        private Gameboard _gameboard;
        private ViewStateInRound _currentViewStateInRound;
        private ViewStateGame _currentViewStateGame;
        private ViewStateOptions _currentViewStateOptions;
        private HistoricStatsState _currentViewStateHistoricStats;

        public ConsoleColor _playerXColor = ConsoleColor.DarkMagenta;
        public ConsoleColor _playerOColor = ConsoleColor.Red;

        #endregion

        #region PROPERTIES
        public GameboardPosition InProgressPosition
        {
            get { return _inProgressPosition; }
            set { _inProgressPosition = value; }
        }

        public ViewStateInRound CurrentViewStateInRound
        {
            get { return _currentViewStateInRound; }
            set { _currentViewStateInRound = value; }
        }

        public ViewStateGame CurrentViewStateGame
        {
            get { return _currentViewStateGame; }
            set { _currentViewStateGame = value; }
        }

        public ViewStateOptions CurrentViewStateOptions
        {
            get { return _currentViewStateOptions; }
            set { _currentViewStateOptions = value; }
        }

        public HistoricStatsState CurrentViewStateHistoricStats
        {
            get { return _currentViewStateHistoricStats; }
            set { _currentViewStateHistoricStats = value; }
        }

        #endregion

        #region CONSTRUCTORS

        public ConsoleView(Gameboard gameboard)
        {
            _gameboard = gameboard;
            _playerXColor = ConsoleColor.DarkMagenta;
            _playerOColor = ConsoleColor.Red;

            InitializeView();

        }

        #endregion

        #region METHODS

        /// <summary>
        /// Initialize the console view
        /// </summary>
        public void InitializeView()
        {
            _currentViewStateGame = ViewStateGame.MainMenu;

            InitializeConsole();
        }

        /// <summary>
        /// configure the console window
        /// </summary>
        public void InitializeConsole()
        {
            ConsoleUtil.WindowWidth = ConsoleConfig.windowWidth;
            ConsoleUtil.WindowHeight = ConsoleConfig.windowHeight;

            Console.BackgroundColor = ConsoleConfig.bodyBackgroundColor;
            Console.ForegroundColor = ConsoleConfig.bodyBackgroundColor;

            ConsoleUtil.WindowTitle = "The Tic-tac-toe Game";
        }

        /// <summary>
        /// display the Continue prompt
        /// </summary>
        public void DisplayContinuePrompt()
        {
            Console.CursorVisible = false;

            Console.WriteLine();

            ConsoleUtil.DisplayMessage("Press any key to continue.");
            ConsoleKeyInfo response = Console.ReadKey();

            Console.WriteLine();
            Console.CursorVisible = true;
        }
        

        /// <summary>
        /// display a continue prompt with custom message displayed
        /// </summary>
        /// <param name="message">prompt message</param>
        public void DisplayContinuePrompt(string message)
        {
            Console.CursorVisible = false;

            Console.WriteLine();

            ConsoleUtil.DisplayMessage(message);
            ConsoleKeyInfo response = Console.ReadKey();

            Console.WriteLine();

            Console.CursorVisible = true;
        }

        /// <summary>
        /// display the maximum attempts reached screen
        /// </summary>
        public void DisplayMaxAttemptsReachedScreen()
        {
            StringBuilder sb = new StringBuilder();

            ConsoleUtil.HeaderText = "Maximum Move Attempts Reached!";
            ConsoleUtil.DisplayReset();

            sb.Append(" It appears that you are having difficulty entering your");
            sb.Append(" choice. Please refer to the instructions and play again.");

            DisplayMessageBox(sb.ToString());

            DisplayContinuePrompt();
        }

        /// <summary>
        /// display message for when no previous player has been selected to go first.
        /// used during turn order process.
        /// </summary>
        public void DisplayNoPreviousFirstPlayerMessage()
        {
            DisplayMessageBox("No previous player detected since game was started!  PlayerX will go first.");

            DisplayContinuePrompt();
        }

        /// <summary>
        /// Displays options and obtains choice regarding player turn order
        /// </summary>
        /// <returns>PlayerSelectionChoice</returns>
        public PlayerSelectionChoice DisplayChoosePlayerToGoFirstScreen()
        {
            PlayerSelectionChoice playerChoice = PlayerSelectionChoice.PlayerXFirst;

            ConsoleUtil.DisplayReset("Choose Starting Player");

            ConsoleUtil.DisplayMessage("Before the game begins, decide who goes first.");
            ConsoleUtil.DisplayMessage("\t1. PlayerX");
            ConsoleUtil.DisplayMessage("\t2. PlayerO");
            ConsoleUtil.DisplayMessage("\t3. Opposite of last round");
            ConsoleUtil.DisplayMessage("\t4. Let the computer decide");

            playerChoice = GetInitialPlayerChoice();

            return playerChoice;
        }

        /// <summary>
        /// Inform the player that their position choice is not available
        /// </summary>
        public void DisplayGamePositionChoiceNotAvailableScreen()
        {
            StringBuilder sb = new StringBuilder();

            ConsoleUtil.HeaderText = "Position Choice Unavailable";
            ConsoleUtil.DisplayReset();

            sb.Append(" It appears that you have chosen a position that is all ready");
            sb.Append(" taken. Please try again.");

            DisplayMessageBox(sb.ToString());

            DisplayContinuePrompt();
        }

        /// <summary>
        /// display the welcome screen
        /// </summary>
        public void DisplayWelcomeScreen()
        {
            StringBuilder sb = new StringBuilder();
            Console.BackgroundColor = ConsoleColor.DarkCyan;

            ConsoleUtil.HeaderText = "The 3D Tic-Tac-Toe Game";
            ConsoleUtil.DisplayReset();

            ConsoleUtil.DisplayMessage("Written by Josiah Pippin and Iryna Narolska");
            ConsoleUtil.DisplayMessage("Northwestern Michigan College");
            Console.WriteLine();

            sb.Clear();
            sb.AppendFormat("This application is designed to allow two players to play ");
            sb.AppendFormat("a game of 3D tic-tac-toe. The rules are the standard rules ");
            sb.AppendFormat("in 3 dimensions for the game with each player taking a turn ");
            sb.AppendFormat("until a winner is decided or no moves remain on the board.");
            ConsoleUtil.DisplayMessage(sb.ToString());
            Console.WriteLine();

            sb.Clear();
            sb.AppendFormat("This game is dedicated to all those noble heroes whom soup ");
            sb.AppendFormat("has taken from us.  You are not forgotten!");
            ConsoleUtil.DisplayMessage(sb.ToString());
            Console.WriteLine();

            DisplayContinuePrompt();
        }

        /// <summary>
        /// display the menu screen and get menu choice
        /// </summary>
        public void DisplayMenuScreen()
        {
            Console.CursorVisible = false;

            ConsoleUtil.HeaderText = "The 3D Tic-tac-toe Game";
            ConsoleUtil.DisplayReset();

            Console.WriteLine("    Main Menu\n");
            Console.WriteLine("\t1. New Game");
            Console.WriteLine("\t2. Rules");
            Console.WriteLine("\t3. Current Game Stats");
            Console.WriteLine("\t4. Historic Game Stats");
            Console.WriteLine("\t5. Options");
            Console.WriteLine("\t6. Quit\n\n");

            MainMenuChoice(GetNumericChoice(NUMBER_OF_MAIN_MENU_CHOICES));
        }

        /// <summary>
        /// Displays game rules screens
        /// </summary>
        public void DisplayRulesScreen()
        {
            StringBuilder sb = new StringBuilder();

            ConsoleUtil.HeaderText = "Rules and Hints";
            ConsoleUtil.DisplayReset();
            sb.AppendFormat("Welcome to 3D Tic Tac Toe! ");
            sb.AppendFormat("Think of the game as a cubed tic tac toe board with three separate ");
            sb.AppendFormat("levels of boards stacked on top of each other.  Players take turns ");
            sb.AppendFormat("adding Xs or Os to the board till someone gets three in a row.  You ");
            sb.AppendFormat("can get the standard wins you’re used to on a single level (as pictured below):");
            ConsoleUtil.DisplayMessage(sb.ToString());
            Console.WriteLine();

            sb.Clear();
            Console.WriteLine(ConsoleUtil.Center("   ╔═══╦═══╦═══╗    ╔═══╦═══╦═══╗    ╔═══╦═══╦═══╗ "));
            Console.WriteLine(ConsoleUtil.Center("   ║   ║   ║   ║    ║   ║   ║   ║    ║   ║   ║   ║ "));
            Console.WriteLine(ConsoleUtil.Center("   ╠═══╬═══╬═══╣    ╠═══╬═══╬═══╣    ╠═══╬═══╬═══╣ "));
            Console.WriteLine(ConsoleUtil.Center("   ║   ║   ║   ║    ║ X ║ X ║ X ║    ║   ║   ║   ║ "));
            Console.WriteLine(ConsoleUtil.Center("   ╠═══╬═══╬═══╣    ╠═══╬═══╬═══╣    ╠═══╬═══╬═══╣ "));
            Console.WriteLine(ConsoleUtil.Center("   ║   ║   ║   ║    ║   ║   ║   ║    ║   ║   ║   ║ "));
            Console.WriteLine(ConsoleUtil.Center("   ╚═══╩═══╩═══╝    ╚═══╩═══╩═══╝    ╚═══╩═══╩═══╝ "));
            Console.WriteLine();
            sb.AppendFormat("But the key to winning is thinking in three dimensions.");
            ConsoleUtil.DisplayMessage(sb.ToString());

            DisplayContinuePrompt("--Press any key to see the next screen--");


            ConsoleUtil.DisplayReset();
            sb.Clear();
            sb.AppendFormat("You can use multiple levels to score vertically:");
            ConsoleUtil.DisplayMessage(sb.ToString());

            Console.WriteLine(ConsoleUtil.Center("   ╔═══╦═══╦═══╗    ╔═══╦═══╦═══╗    ╔═══╦═══╦═══╗ "));
            Console.WriteLine(ConsoleUtil.Center("   ║ X ║   ║   ║    ║ X ║   ║   ║    ║ X ║   ║   ║ "));
            Console.WriteLine(ConsoleUtil.Center("   ╠═══╬═══╬═══╣    ╠═══╬═══╬═══╣    ╠═══╬═══╬═══╣ "));
            Console.WriteLine(ConsoleUtil.Center("   ║   ║   ║   ║    ║   ║   ║   ║    ║   ║   ║   ║ "));
            Console.WriteLine(ConsoleUtil.Center("   ╠═══╬═══╬═══╣    ╠═══╬═══╬═══╣    ╠═══╬═══╬═══╣ "));
            Console.WriteLine(ConsoleUtil.Center("   ║   ║   ║   ║    ║   ║   ║   ║    ║   ║   ║   ║ "));
            Console.WriteLine(ConsoleUtil.Center("   ╚═══╩═══╩═══╝    ╚═══╩═══╩═══╝    ╚═══╩═══╩═══╝ "));

            DisplayContinuePrompt("--Press any key to see the next screen--");


            ConsoleUtil.DisplayReset();
            sb.Clear();
            sb.AppendFormat("Or diagonally, left to right:");
            ConsoleUtil.DisplayMessage(sb.ToString());

            Console.WriteLine(ConsoleUtil.Center("   ╔═══╦═══╦═══╗    ╔═══╦═══╦═══╗    ╔═══╦═══╦═══╗ "));
            Console.WriteLine(ConsoleUtil.Center("   ║   ║   ║   ║    ║   ║   ║   ║    ║   ║   ║   ║ "));
            Console.WriteLine(ConsoleUtil.Center("   ╠═══╬═══╬═══╣    ╠═══╬═══╬═══╣    ╠═══╬═══╬═══╣ "));
            Console.WriteLine(ConsoleUtil.Center("   ║ X ║   ║   ║    ║   ║ X ║   ║    ║   ║   ║ X ║ "));
            Console.WriteLine(ConsoleUtil.Center("   ╠═══╬═══╬═══╣    ╠═══╬═══╬═══╣    ╠═══╬═══╬═══╣ "));
            Console.WriteLine(ConsoleUtil.Center("   ║   ║   ║   ║    ║   ║   ║   ║    ║   ║   ║   ║ "));
            Console.WriteLine(ConsoleUtil.Center("   ╚═══╩═══╩═══╝    ╚═══╩═══╩═══╝    ╚═══╩═══╩═══╝ "));
            Console.WriteLine();

            sb.Clear();
            sb.AppendFormat("Or up and down:");
            ConsoleUtil.DisplayMessage(sb.ToString());

            Console.WriteLine(ConsoleUtil.Center("   ╔═══╦═══╦═══╗    ╔═══╦═══╦═══╗    ╔═══╦═══╦═══╗ "));
            Console.WriteLine(ConsoleUtil.Center("   ║   ║ X ║   ║    ║   ║   ║   ║    ║   ║   ║   ║ "));
            Console.WriteLine(ConsoleUtil.Center("   ╠═══╬═══╬═══╣    ╠═══╬═══╬═══╣    ╠═══╬═══╬═══╣ "));
            Console.WriteLine(ConsoleUtil.Center("   ║   ║   ║   ║    ║   ║ X ║   ║    ║   ║   ║   ║ "));
            Console.WriteLine(ConsoleUtil.Center("   ╠═══╬═══╬═══╣    ╠═══╬═══╬═══╣    ╠═══╬═══╬═══╣ "));
            Console.WriteLine(ConsoleUtil.Center("   ║   ║   ║   ║    ║   ║   ║   ║    ║   ║ X ║   ║ "));
            Console.WriteLine(ConsoleUtil.Center("   ╚═══╩═══╩═══╝    ╚═══╩═══╩═══╝    ╚═══╩═══╩═══╝ "));

            DisplayContinuePrompt("--Press any key to see the next screen--");


            ConsoleUtil.DisplayReset();
            sb.Clear();
            sb.AppendFormat("Even diagonally, DIAGONALLY:");
            ConsoleUtil.DisplayMessage(sb.ToString());

            Console.WriteLine(ConsoleUtil.Center("   ╔═══╦═══╦═══╗    ╔═══╦═══╦═══╗    ╔═══╦═══╦═══╗ "));
            Console.WriteLine(ConsoleUtil.Center("   ║ X ║   ║   ║    ║   ║   ║   ║    ║   ║   ║   ║ "));
            Console.WriteLine(ConsoleUtil.Center("   ╠═══╬═══╬═══╣    ╠═══╬═══╬═══╣    ╠═══╬═══╬═══╣ "));
            Console.WriteLine(ConsoleUtil.Center("   ║   ║   ║   ║    ║   ║ X ║   ║    ║   ║   ║   ║ "));
            Console.WriteLine(ConsoleUtil.Center("   ╠═══╬═══╬═══╣    ╠═══╬═══╬═══╣    ╠═══╬═══╬═══╣ "));
            Console.WriteLine(ConsoleUtil.Center("   ║   ║   ║   ║    ║   ║   ║   ║    ║   ║   ║ X ║ "));
            Console.WriteLine(ConsoleUtil.Center("   ╚═══╩═══╩═══╝    ╚═══╩═══╩═══╝    ╚═══╩═══╩═══╝ "));
            Console.WriteLine();

            sb.Clear();
            sb.AppendFormat("Keep your eyes open and be ready for strategies from every angle.       Have fun! :)");
            ConsoleUtil.DisplayMessage(sb.ToString());

            DisplayContinuePrompt("--Press any key to return to the Main Menu--");
        }

        /// <summary>
        /// Displays the Current Game Stats screen, a slightly more informative version of the current game status
        /// </summary>
        /// <param name="roundsPlayed"></param>
        /// <param name="playerXWins"></param>
        /// <param name="playerOWins"></param>
        /// <param name="catsGames"></param>
        public void DisplayCurrentGameStatsScreen(int roundsPlayed, int playerXWins, int playerOWins, int catsGames)
        {
            ConsoleUtil.HeaderText = "Current Game Stats";
            ConsoleUtil.DisplayReset();

            // calculate percentages with helper method to compensate for instances where no round has been played
            double playerXPercentageWins = CurrentGameStatsHelper((double)playerXWins / roundsPlayed);
            double playerOPercentageWins = CurrentGameStatsHelper((double)playerOWins / roundsPlayed);
            double percentageOfCatsGames = CurrentGameStatsHelper((double)catsGames / roundsPlayed);
            double playerXPercentageTotalWins = ((double)(playerXWins + playerOWins) / playerXWins);
            double playerOPercentageTotalWins = 1 - playerXPercentageTotalWins;
            playerXPercentageTotalWins = CurrentGameStatsHelper(playerXPercentageTotalWins);
            playerOPercentageTotalWins = CurrentGameStatsHelper(playerOPercentageTotalWins);


            Console.WriteLine();
            ConsoleUtil.DisplayMessage("Rounds Played: " + roundsPlayed);
            ConsoleUtil.DisplayMessage("Rounds for Player X: " + playerXWins + " - " + String.Format("{0:P2}", playerXPercentageWins));
            ConsoleUtil.DisplayMessage("Rounds for Player O: " + playerOWins + " - " + String.Format("{0:P2}", playerOPercentageWins));
            ConsoleUtil.DisplayMessage("Cat's Games: " + catsGames + " - " + String.Format("{0:P2}", percentageOfCatsGames));
            Console.WriteLine();

            Console.WriteLine(ConsoleUtil.Center("--Total Current Win Record--"));
            Console.WriteLine(ConsoleUtil.Center("Player X: " + String.Format("{0:P2}", playerXPercentageTotalWins) + " vs "
                                                          + String.Format("{0:P2}", playerOPercentageTotalWins) + " :Player O"));

            DisplayContinuePrompt("--Press any key to return to the Main Menu--");
        }

        /// <summary>
        /// checks and formats a calculated percent to be certain it is displayable as such
        /// </summary>
        /// <param name="percentToCheck"></param>
        /// <returns>double</returns>
        public double CurrentGameStatsHelper(double percentToCheck)
        {
            double percent = 0;

            // check for NaN and positive and negative infinity
            if (percentToCheck.ToString() != "NaN" && percentToCheck <= 1)
            {
                if (percentToCheck < 0)
                {
                    percent = 1;
                }
                else
                {
                    percent = percentToCheck;
                }
            }

            return percent;
        }

        /// <summary>
        /// display Historic Game Stats choices and get player choice
        /// </summary>
        public void DisplayHistoricGameStatsScreen()
        {
            ConsoleUtil.DisplayReset("Historic Game Stats");

            ConsoleUtil.DisplayMessage("Make a selection:");
            ConsoleUtil.DisplayMessage("\t1. High Scores");
            ConsoleUtil.DisplayMessage("\t2. Find Specific Player Win Record");
            Console.WriteLine();
            ConsoleUtil.DisplayMessage("\t3. Return to Main Menu");

            HistoricStatsChoice(GetNumericChoice(NUMBER_OF_HISTORIC_STAT_CHOICES));
        }

        /// <summary>
        /// display option choices and get player choice
        /// </summary>
        public void DisplayOptionsScreen()
        {
            ConsoleUtil.DisplayReset("Game Options");

            ConsoleUtil.DisplayMessage("Make a selection:");
            ConsoleUtil.DisplayMessage("\t1. Change Player Colors");
            ConsoleUtil.DisplayMessage("\t2. Save Win Data");
            ConsoleUtil.DisplayMessage("\t3. Erase Save Data");
            Console.WriteLine();
            ConsoleUtil.DisplayMessage("\t4. Return to Main Menu");


            OptionsChoice(GetNumericChoice(NUMBER_OF_OPTION_CHOICES));
        }

        /// <summary>
        /// display a closing screen when the user quits the application
        /// </summary>
        public void DisplayClosingScreen()
        {
            ConsoleUtil.HeaderText = "Good bye for now!";
            ConsoleUtil.DisplayReset();

            ConsoleUtil.DisplayMessage("Thank you for using The 3D Tic-tac-toe Game.");

            DisplayContinuePrompt("--Press any key to exit--");

            System.Environment.Exit(1);
        }

        public void DisplayGameArea()
        {
            ConsoleUtil.HeaderText = "--Game In Progress--";
            ConsoleUtil.DisplayReset();

            DisplayGameboard();
            DisplayGameStatus();
        }

        public void DisplayCurrentGameStatus(int roundsPlayed, int playerXWins, int playerOWins, int catsGames)
        {
            ConsoleUtil.HeaderText = "Current Game Status";
            ConsoleUtil.DisplayReset();

            double playerXPercentageWins = (double)playerXWins / roundsPlayed;
            double playerOPercentageWins = (double)playerOWins / roundsPlayed;
            double percentageOfCatsGames = (double)catsGames / roundsPlayed;

            ConsoleUtil.DisplayMessage(ConsoleUtil.Center("Rounds Played: " + roundsPlayed));
            ConsoleUtil.DisplayMessage("Rounds for Player X: " + playerXWins + " - " + String.Format("{0:P2}", playerXPercentageWins));
            ConsoleUtil.DisplayMessage("Rounds for Player O: " + playerOWins + " - " + String.Format("{0:P2}", playerOPercentageWins));
            ConsoleUtil.DisplayMessage("Cat's Games: " + catsGames + " - " + String.Format("{0:P2}", percentageOfCatsGames));

            DisplayContinuePrompt();
        }

        public void DisplayGameStatus()
        {
            StringBuilder sb = new StringBuilder();

            switch (_gameboard.CurrentRoundState)
            {
                case Gameboard.GameboardState.NewRound:
                    //
                    // The new game status should not be an necessary option here
                    //
                    break;
                case Gameboard.GameboardState.PlayerXTurn:
                    DisplayMessageBox("It is currently Player X's turn.");
                    break;
                case Gameboard.GameboardState.PlayerOTurn:
                    DisplayMessageBox("It is currently Player O's turn.");
                    break;
                case Gameboard.GameboardState.PlayerXWin:
                    DisplayMessageBox("Player X Wins! Press any key to continue.");

                    Console.CursorVisible = false;
                    Console.ReadKey();
                    Console.CursorVisible = true;
                    break;
                case Gameboard.GameboardState.PlayerOWin:
                    DisplayMessageBox("Player O Wins! Press any key to continue.");

                    Console.CursorVisible = false;
                    Console.ReadKey();
                    Console.CursorVisible = true;
                    break;
                case Gameboard.GameboardState.CatsGame:
                    DisplayMessageBox("Cat's Game! Press any key to continue.");

                    Console.CursorVisible = false;
                    Console.ReadKey();
                    Console.CursorVisible = true;
                    break;
                default:
                    break;
            }
        }

        public void DisplayMessageBox(string message)
        {
            string leftMargin = new String(' ', ConsoleConfig.displayHorizontalMargin);
            string topBottom = new String('*', ConsoleConfig.windowWidth - 2 * ConsoleConfig.displayHorizontalMargin);

            StringBuilder sb = new StringBuilder();

            Console.SetCursorPosition(0, MESSAGEBOX_VERTICAL_LOCATION);
            Console.WriteLine(leftMargin + topBottom);

            Console.WriteLine(ConsoleUtil.Center("Game Status"));

            //overwrite any previous single line message
            Console.WriteLine(ConsoleUtil.FillStringWithSpaces(ConsoleUtil.WindowWidth));
            Console.SetCursorPosition(0, MESSAGEBOX_VERTICAL_LOCATION + 2);

            ConsoleUtil.DisplayMessage(message);
            Console.WriteLine(Environment.NewLine + leftMargin + topBottom);
        }

        /// <summary>
        /// display the current game board as a set of three levels
        /// </summary>

        private void DisplayGameboard()
        {
            //
            // move cursor below header
            //

            for (int level = 0; level < 3; level++)
            {
                Console.SetCursorPosition(level * GAMEBOARD_HORIZONTAL_OFFSET, GAMEBOARD_VERTICAL_LOCATION - 1);
                if (_inProgressPosition.Level == -1)
                {
                    Console.Write("               " + (level + 1) + "        ");
                }
                else if (level == _inProgressPosition.Level - 1 && _inProgressPosition.Row != -1)
                {
                    Console.Write("           1   2   3    ");
                }
                else
                {
                    Console.Write("                      ");
                }
                Console.SetCursorPosition(level * GAMEBOARD_HORIZONTAL_OFFSET, GAMEBOARD_VERTICAL_LOCATION);

                Console.Write("         ╔═══╦═══╦═══╗");
                int verticalAdjustment = 1;

                //╣║╗╝╚╔╩╦╠╬═
                for (int row = 0; row < 3; row++)
                {
                    Console.SetCursorPosition(level * GAMEBOARD_HORIZONTAL_OFFSET, GAMEBOARD_VERTICAL_LOCATION + verticalAdjustment);

                    if (level == _inProgressPosition.Level - 1 && _inProgressPosition.Level != -1 && _inProgressPosition.Row == -1)
                    {
                        Console.Write("      " + (row + 1) + "  ║");
                    }
                    else if (level == _inProgressPosition.Level - 1 && row == _inProgressPosition.Row - 1)
                    {
                        Console.Write("    ---> ║");
                    }
                    else
                    {
                        Console.Write("         ║");
                    }


                    for (int column = 0; column < 3; column++)
                    {
                        if (_gameboard.PositionState[level, row, column] == Gameboard.PlayerPiece.None)
                        {
                            Console.Write("   ║");
                        }
                        else
                        {
                            string playerPiece = "";

                            Console.ForegroundColor = ConsoleConfig.bodyBackgroundColor;
                            if (_gameboard.PositionState[level, row, column] == Gameboard.PlayerPiece.X)
                            {
                                Console.BackgroundColor = _playerXColor;
                                playerPiece = " X ";

                            }
                            else if (_gameboard.PositionState[level, row, column] == Gameboard.PlayerPiece.O)
                            {
                                Console.BackgroundColor = _playerOColor;
                                playerPiece = " O ";
                            }

                            Console.Write(playerPiece);

                            Console.BackgroundColor = Console.ForegroundColor;
                            Console.ForegroundColor = ConsoleConfig.bodyForegroundColor;
                            Console.Write("║");
                        }
                        if (column == 2) { verticalAdjustment++; }
                    }

                    Console.SetCursorPosition(level * GAMEBOARD_HORIZONTAL_OFFSET, GAMEBOARD_VERTICAL_LOCATION + verticalAdjustment);

                    if (verticalAdjustment <= GAMEBOARD_CONSOLE_HEIGHT - 2)
                    {
                        Console.Write("         ╠═══╬═══╬═══╣");
                    }
                    else
                    {
                        Console.Write("         ╚═══╩═══╩═══╝");
                    }
                    verticalAdjustment++;
                }
            }
        }


        /// <summary>
        /// display prompt for a player's next move
        /// </summary>
        /// <param name="coordinateType"></param>
        private void DisplayPositionPrompt(string coordinateType)
        {
            //
            // Clear line by overwriting with spaces
            //
            Console.SetCursorPosition(POSITIONPROMPT_HORIZONTAL_LOCATION, POSITIONPROMPT_VERTICAL_LOCATION);
            Console.Write(new String(' ', ConsoleConfig.windowWidth));
            //
            // Write new prompt
            //
            Console.SetCursorPosition(POSITIONPROMPT_HORIZONTAL_LOCATION, POSITIONPROMPT_VERTICAL_LOCATION);
            Console.Write("Enter " + coordinateType + " number (or q to quit round): ");
        }

        /// <summary>
        /// Display a Yes or No prompt with a message and custom header
        /// </summary>
        /// <param name="promptMessage">prompt message</param>
        /// <param name="customHeader">header message</param>
        /// <returns>bool where true = yes</returns>
        private bool DisplayGetYesNoPrompt(string promptMessage, string customHeader)
        {
            bool yesNoChoice = false;
            bool validResponse = false;
            string userResponse;

            while (!validResponse)
            {
                ConsoleUtil.DisplayReset(customHeader);

                ConsoleUtil.DisplayPromptMessage(promptMessage + "(yes/no)");
                userResponse = Console.ReadLine();

                if (userResponse.ToUpper() == "YES" || userResponse.ToUpper() == "Y")
                {
                    validResponse = true;
                    yesNoChoice = true;
                }
                else if (userResponse.ToUpper() == "NO" || userResponse.ToUpper() == "N")
                {
                    validResponse = true;
                    yesNoChoice = false;
                }
                else
                {
                    ConsoleUtil.DisplayMessage(
                        "It appears that you have entered an incorrect response." +
                        " Please enter either \"yes\" or \"no\"."
                        );
                    DisplayContinuePrompt();
                }
            }

            return yesNoChoice;
        }
        /// <summary>
        /// Displays and implements player color choices
        /// </summary>
        public void DisplayPlayerColorChoiceScreen()
        {
            bool choosingColor = true;
            while (choosingColor)
            {
                ConsoleUtil.DisplayReset("Player Color Settings");

                ConsoleUtil.DisplayMessage("Choose the player who's color you would like to change:");

                Console.WriteLine("\n");
                Console.Write("\t1: ");
                Console.ForegroundColor = Console.BackgroundColor;
                Console.BackgroundColor = _playerXColor;
                Console.Write(" PlayerX ");
                Console.BackgroundColor = ConsoleConfig.bodyBackgroundColor;
                Console.ForegroundColor = ConsoleUtil.BodyForegroundColor;

                Console.Write("\n\t2: ");
                Console.ForegroundColor = Console.BackgroundColor;
                Console.BackgroundColor = _playerOColor;
                Console.Write(" PlayerO ");
                Console.BackgroundColor = ConsoleConfig.bodyBackgroundColor;
                Console.ForegroundColor = ConsoleUtil.BodyForegroundColor;

                Console.WriteLine("\n\n\t3: Return to Options Menu");

                Console.WriteLine("\n\n\t  --Choose 1, 2 or 3 --");

                int playerChoice = GetNumericChoice(3);
                switch (playerChoice)
                {
                    case 1:
                        _playerXColor = DisplayColorChoices("PlayerX");
                        break;
                    case 2:
                        _playerOColor = DisplayColorChoices("PlayerO");
                        break;
                    case 3:
                        choosingColor = false;
                        break;
                    default:
                        break;
                }
            }
        }

        /// <summary>
        /// Displays available color choices a game player and reassigns a new color
        /// </summary>
        /// <param name="playerName"></param>
        /// <returns>ConsoleColor</returns>
        private ConsoleColor DisplayColorChoices(string playerName)
        {
            ConsoleColor playerColorChoice;

            int counter = 1;
            ConsoleUtil.DisplayReset(playerName + " Color Choice");
            ConsoleUtil.DisplayMessage("Which color would you like to assign to " + playerName + ":\n\t");
            foreach (var color in PLAYER_COLOR_CHOICES)
            {
                // write color selection to console with spacing padding
                Console.Write("\t" + counter + ": ");
                Console.ForegroundColor = Console.BackgroundColor;
                Console.BackgroundColor = color;
                Console.Write(" " + color.ToString());
                for (int i = 0; i <= PLAYER_COLOR_CHOICE_SELECTION_BLOCK - color.ToString().Length; i++)
                {
                    Console.Write(" ");
                }
                Console.BackgroundColor = ConsoleUtil.BodyBackgroundColor;
                Console.ForegroundColor = ConsoleUtil.BodyForegroundColor;
                Console.Write("\n");
                counter++;
            }

            playerColorChoice = PLAYER_COLOR_CHOICES[GetNumericChoice(PLAYER_COLOR_CHOICES.Length) - 1];

            return playerColorChoice;
        }

        /// <summary>
        /// Displays and gathers player initials for use with historic game stats
        /// </summary>
        /// <returns></returns>
        public string DisplayGetPlayerInfoToRetrieve()
        {
            string playerInitials = "";

            ConsoleUtil.DisplayReset("Total Player Wins Search");

            Console.WriteLine();
            ConsoleUtil.DisplayMessage("Enter the 3 letter initials of the player to see total saved wins");
            ConsoleUtil.DisplayMessage("for that player (or type q to return to the previous menu):");
            Console.SetCursorPosition(POSITIONPROMPT_HORIZONTAL_LOCATION, POSITIONPROMPT_VERTICAL_LOCATION - 4);

            Console.CursorVisible = true;

            playerInitials = Console.ReadLine();

            if (playerInitials.ToUpper() != "Q" && playerInitials.Length != 3)
            {
                throw new PlayerInitialOutOfRangeException("Player initials must be 3 letters in length!");
            }

            return playerInitials;
        }

        /// <summary>
        /// get player wins
        /// </summary>
        public int DisplayGetPlayerWinSet(int playerXUnsavedWins, int playerOUnsavedWins)
        {

            bool chosingPlayer = true;
            int numberOfWins = 0;

            while (chosingPlayer)
            {
                string userEntry;
                ConsoleUtil.DisplayReset("Choose Player to Save");
                ConsoleUtil.DisplayMessage("What player's score would you like you save?");
                Console.WriteLine();
                ConsoleUtil.DisplayMessage("Options: X for Player X --or-- O for Player O");
                ConsoleUtil.DisplayMessage("(or type q to go to back to the options menu)");
                Console.SetCursorPosition(POSITIONPROMPT_HORIZONTAL_LOCATION, POSITIONPROMPT_VERTICAL_LOCATION - 3);
                userEntry = Console.ReadKey().KeyChar.ToString();
                if (userEntry == "O" || userEntry == "o")
                {
                    numberOfWins = playerOUnsavedWins;
                    chosingPlayer = false;
                }
                else if (userEntry == "X" || userEntry == "x")
                {
                    numberOfWins = playerXUnsavedWins;
                    chosingPlayer = false;
                }
                else if (userEntry == "Q" || userEntry == "q")
                {
                    numberOfWins = -1;
                    chosingPlayer = false;
                }
            }

            return numberOfWins;
        }

        /// <summary>
        /// get player initials
        /// </summary>
        /// <returns></returns>
        public string DisplayGetPlayerName()
        {
            string playerInitials = "";

            //
            // get player name
            //
            ConsoleUtil.DisplayReset("Choose Player Initials for Save");
            Console.WriteLine();
            ConsoleUtil.DisplayMessage("Enter the 3 letter initials of the player to save:");
            Console.SetCursorPosition(POSITIONPROMPT_HORIZONTAL_LOCATION, POSITIONPROMPT_VERTICAL_LOCATION - 4);
            Console.CursorVisible = true;
            playerInitials = Console.ReadLine();

            if (playerInitials.Length != 3)
            {
                throw new PlayerInitialOutOfRangeException("Player initials must be 3 characters in length.");
            }

            return playerInitials;

        }

        /// <summary>
        /// Display historic scores as a listing
        /// </summary>
        /// <param name="historicScores"></param>
        public void DisplayHistoricScores(List<PlayerWinsRecord> historicScores)
        {
            ConsoleUtil.DisplayReset("Top Saved Wins");

            Console.WriteLine("\tHighest Saved Wins:\n");
            
            foreach (var historicScore in historicScores)
            {

                ConsoleUtil.DisplayMessage(historicScore.PlayerInitial + " has a total win record of " + historicScore.PlayerWins + ".");
            }
            Console.WriteLine();
            DisplayContinuePrompt("Press enter to return to Historic Game Stats.");
        }

        /// <summary>
        /// Displays an error message in the console as passed from controller
        /// </summary>
        /// <param name="errorMessage"></param>
        public void DisplayErrorMessage (string errorMessage)
        {
            DisplayMessageBox(errorMessage);

            DisplayContinuePrompt();
        }

        /// <summary>
        /// Carry out menu selection
        /// </summary>
        /// <param name="menuChoice">menu choice number</param>
        private void MainMenuChoice(int menuChoice)
        {
            switch (menuChoice)
            {
                case 1:
                    // new game selected
                    _currentViewStateGame = ViewStateGame.GamePlay;
                    break;
                case 2:
                    // rules screen selected
                    DisplayRulesScreen();
                    break;
                case 3:
                    // current game stats selected
                    _currentViewStateGame = ViewStateGame.CurrentGameStats;
                    break;
                case 4:
                    // historic game stats selected
                    _currentViewStateGame = ViewStateGame.HistoricStats;
                    break;
                case 5:
                    // options selected
                    _currentViewStateGame = ViewStateGame.Options;
                    break;
                case 6:
                    // quit selected
                    if(DisplayGetYesNoPrompt("Do you want to quit the game?", "Quit"))
                    {
                        _currentViewStateGame = ViewStateGame.Quit;
                    }
                    break;
                default:
                    break;
            }
        }

        /// <summary>
        /// Carry out Options choice selection
        /// </summary>
        /// <param name="option">option choice number</param>
        private void OptionsChoice(int option)
        {
            switch (option)
            {
                case 1:
                    // change player colors 
                    DisplayPlayerColorChoiceScreen();
                    break;
                case 2:
                    // save data selected
                    _currentViewStateOptions = ViewStateOptions.SaveData;
                    break;
                case 3:
                    // clear save data selected
                    if (DisplayGetYesNoPrompt("Are you sure you want to erase all save data?", "!!!Clear Save Data!!!"))
                    {
                        _currentViewStateOptions = ViewStateOptions.ClearData;
                    }
                    break;
                case 4:
                    // return to main menu selected
                    _currentViewStateOptions = ViewStateOptions.ReturnToMenu;
                    break;
                default:
                    break;
            }
        }

        /// <summary>
        /// Carry out Options choice selection
        /// </summary>
        /// <param name="choice">historic stat choice number</param>
        private void HistoricStatsChoice(int choice)
        {
            switch (choice)
            {
                case 1:
                    // display high scores selected
                    _currentViewStateHistoricStats = HistoricStatsState.HighScores;
                    break;
                case 2:
                    // filter to display win record for a specific player selected
                    _currentViewStateHistoricStats = HistoricStatsState.Filtering;
                    break;
                case 3:
                    // return to main menu
                    _currentViewStateHistoricStats = HistoricStatsState.ReturnToMenu;
                    break;
                default:
                    break;
            }
        }

        /// <summary>
        /// Get initial player choice selection
        /// </summary>
        /// <returns>PlayerSelectionChoice</returns>
        private PlayerSelectionChoice GetInitialPlayerChoice()
        {
            bool validMenuChoice = false;
            PlayerSelectionChoice tempPlayerSelectionChoice = PlayerSelectionChoice.None;

            while (!validMenuChoice)
            {
                Console.SetCursorPosition(POSITIONPROMPT_HORIZONTAL_LOCATION, POSITIONPROMPT_VERTICAL_LOCATION);
                Console.Write("    Please select an option from 1 to " + NUMBER_OF_PLAYER_SELECTION_CHOICES + ": ");

                int playerChoice = -1;
                if (int.TryParse(Console.ReadKey().KeyChar.ToString(), out playerChoice))
                {
                    //
                    // number within range of player selection options
                    //
                    if (playerChoice >= 1 && playerChoice <= NUMBER_OF_PLAYER_SELECTION_CHOICES)
                    {
                        validMenuChoice = Enum.TryParse((playerChoice - 1).ToString(), out tempPlayerSelectionChoice);
                    }
                    //
                    // player selection choice number out of range
                    //
                    else
                    {
                        Console.WriteLine("\b \n\n    ***Valid choices are numbers 1 - " + NUMBER_OF_PLAYER_SELECTION_CHOICES + "***");
                    }
                }
                //
                // response cannot be parsed as a valid int
                //
                else
                {
                    Console.WriteLine("\b \n\n    ***Valid choices are numbers 1 - " + NUMBER_OF_PLAYER_SELECTION_CHOICES + "***");
                }
            }

            return tempPlayerSelectionChoice;
        }

        /// <summary>
        /// Get a valid numeric choice based on an input parameter
        /// </summary>
        /// <returns>int</returns>
        private int GetNumericChoice(int numberOfChoices)
        {
            bool validNumericChoice = false;
            int tempNumericChoice = -1;

            while (!validNumericChoice)
            {
                Console.SetCursorPosition(POSITIONPROMPT_HORIZONTAL_LOCATION, POSITIONPROMPT_VERTICAL_LOCATION + 1);
                Console.Write("    Please select an option from 1 to " + numberOfChoices + ": ");

                if (int.TryParse(Console.ReadKey().KeyChar.ToString(), out tempNumericChoice))
                {
                    //
                    // number within range of specified number of choices
                    //
                    if (tempNumericChoice >= 1 && tempNumericChoice <= numberOfChoices)
                    {
                        validNumericChoice = true;
                    }
                    //
                    // option choice number out of range
                    //
                    else
                    {
                        Console.WriteLine("\b \n\n    ***Valid choices are numbers 1 - " + numberOfChoices + "***");
                    }
                }
                //
                // response cannot be parsed as a valid int
                //
                else
                {
                    Console.WriteLine("\b \n\n    ***Valid choices are numbers 1 - " + numberOfChoices + "***");
                }
            }

            return tempNumericChoice;
        }

        /// <summary>
        /// Get a player's position choice within the correct range of the array
        /// Note: The ConsoleView is allowed access to the GameboardPosition struct.
        /// </summary>
        /// <returns>GameboardPosition</returns>
        public GameboardPosition GetPlayerPositionChoice()
        {
            //
            // Initialize gameboardPosition with -1 values
            //
            GameboardPosition gameboardPosition = new GameboardPosition(-1, -1, -1);

            //
            // Get level number from player.
            //
            gameboardPosition.Level = PlayerCoordinateChoice("Level");
            _inProgressPosition.Level = gameboardPosition.Level;
            
            //
            // Get row number from player.
            //
            DisplayGameArea();

            if (_currentViewStateInRound == ViewStateInRound.RoundEnabled)
            {
                gameboardPosition.Row = PlayerCoordinateChoice("Row");
                _inProgressPosition.Row = gameboardPosition.Row;
            }

            //
            // Get column number.
            //
            DisplayGameArea();

            if (_currentViewStateInRound == ViewStateInRound.RoundEnabled)
            {
                gameboardPosition.Column = PlayerCoordinateChoice("Column");
                _inProgressPosition = new GameboardPosition(-1, -1, -1);
            }

            return gameboardPosition;

        }

        /// <summary>
        /// Validate the player's coordinate response for integer and range
        /// </summary>
        /// <param name="coordinateType">an integer value within proper range or -1</param>
        /// <returns>string</returns>
        private int PlayerCoordinateChoice(string coordinateType)
        {
            int tempCoordinate = -1;
            int numOfPlayerAttempts = 1;
            int maxNumOfPlayerAttempts = 4;

            while ((numOfPlayerAttempts <= maxNumOfPlayerAttempts && _currentViewStateInRound != ViewStateInRound.PlayerQuit))
            {
                DisplayPositionPrompt(coordinateType);
                string playerInput = Console.ReadLine();
                //
                // Check for player exiting round
                //
                if (playerInput == "q" || playerInput == "Q")
                {    
                    if(DisplayGetYesNoPrompt("Are you sure you want to exit this round?", "Confirm Round Exit"))
                    {
                        _currentViewStateInRound = ViewStateInRound.PlayerQuit;
                    }
                    else
                    {
                        DisplayGameArea();
                    }
                }
                else if (int.TryParse(playerInput, out tempCoordinate))
                {
                    //
                    // Player response within range
                    //
                    if (tempCoordinate >= 1 && tempCoordinate <= _gameboard.MaxNumOfLevelsRowsColumns)
                    {
                        // Overwrite any previous instructions in the message box with current player turn info
                        if (_gameboard.CurrentRoundState == Gameboard.GameboardState.PlayerXTurn)
                        {
                            DisplayMessageBox("It is currently Player X's turn.");
                        }
                        else if (_gameboard.CurrentRoundState == Gameboard.GameboardState.PlayerOTurn)
                        {
                            DisplayMessageBox("It is currently Player O's turn.");
                        }

                        return tempCoordinate;
                    }
                    //
                    // Player response out of range
                    //
                    else
                    {
                        DisplayMessageBox(coordinateType + " numbers are limited to (1,2,3)");
                    }
                }
                //
                // Player response cannot be parsed as integer
                //
                else
                {
                    DisplayMessageBox(coordinateType + " numbers are limited to (1,2,3)");
                }

                //
                // Increment the number of player attempts
                //
                numOfPlayerAttempts++;
            }

            //
            // Player used maximum number of attempts, set view state and return
            //
            if (_currentViewStateInRound != ViewStateInRound.PlayerQuit)
            {
                _currentViewStateInRound = ViewStateInRound.PlayerUsedMaxAttempts;
            }

            return tempCoordinate;
        }

        #endregion
    }
}
