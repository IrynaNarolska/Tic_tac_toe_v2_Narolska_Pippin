﻿Title: Tic-Tac-Toe Game Application
Description: This application allows two users playing a 3D tic-tac-toe game using the console UI. The purpose of the application to demonstrate encapsulation and the MVC design pattern.
Authors: Josiah Pippin and Iryna Narolska
Template Author: John E velis
Dated Created: 6/12/2015 (template version)
Last Modified: 9/27/2016
Instructions for Use: 