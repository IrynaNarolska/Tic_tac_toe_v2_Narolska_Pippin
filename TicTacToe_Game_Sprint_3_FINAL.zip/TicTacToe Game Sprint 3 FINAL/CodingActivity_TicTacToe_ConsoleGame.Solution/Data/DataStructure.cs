﻿//using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodingActivity_TicTacToe_ConsoleGame
{
    /// <summary>
    /// Class for storing data structure properties
    /// </summary>
    public class DataStructure
    {
        public const string DataFilePath = "Data\\PlayerWinRecord.txt";
        public const char Delineator = ',';
    }
}
