﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodingActivity_TicTacToe_ConsoleGame
{
    /// <summary>
    /// class for storing a single set of player wins
    /// </summary>
    public class PlayerWinsRecord : IComparable<PlayerWinsRecord>
    {
        public string PlayerInitial { get; set; }
        public int PlayerWins { get; set; }

        //sorting functionality from http://orydberg.azurewebsites.net/Posts/2013/4_HowToSortACSharpList.aspx
        public int CompareTo(PlayerWinsRecord other)
        {
            return this.PlayerWins.CompareTo(other.PlayerWins);
        }
    }
}
