﻿using CodingActivity_TicTacToe_ConsoleGame.Controller;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodingActivity_TicTacToe_ConsoleGame
{
    public class GameController
    {
        #region ENUMS

        private enum Player
        {
            PlayerX,
            PlayerO,
            None
        }

        #endregion

        #region FIELDS
        //
        // track game and round status
        //
        private bool _playingGame;
        private bool _playingRound;

        private int _roundNumber;

        //
        // track player status
        //
        private Player _movesFirst;

        //
        // track the results of multiple rounds
        //
        private int _playerXNumberOfWins;
        private int _playerONumberOfWins;
        private int _numberOfCatsGames;

        //
        // persistence related fields
        //
        private int _playerXUnsavedWins;
        private int _playerOUnsavedWins;

        //
        // instantiate a Gameboard object
        // instantiate a GameView object and give it access to the Gameboard object
        //
        private static Gameboard _gameboard = new Gameboard();
        private static ConsoleView _gameView = new ConsoleView(_gameboard);

        #endregion

        #region PROPERTIES



        #endregion

        #region CONSTRUCTORS

        public GameController()
        {
            InitializeGame();
            PlayGame();
        }
        
        #endregion

        #region METHODS

        /// <summary>
        /// Initialize the multi-round game.
        /// </summary>
        public void InitializeGame()
        {
            //
            // Initialize game variables
            //
            _playingGame = true;
            _playingRound = false;
            _roundNumber = 0;
            _playerONumberOfWins = 0;
            _playerXNumberOfWins = 0;
            _numberOfCatsGames = 0;
            _playerXUnsavedWins = 0;
            _playerOUnsavedWins = 0;
            _movesFirst = Player.None;

            //
            // Initialize game board status
            //
            _gameboard.InitializeGameboard();
        }


        /// <summary>
        /// Game Loop
        /// </summary>
        public void PlayGame()
        {
            _gameView.DisplayWelcomeScreen();

            //
            // Game loop through menu
            //
            while (_playingGame)
            {
                ManageGameStateTasks();
                //
                // Round loop
                //
                while (_playingRound)
                {
                    //
                    // Perform the task associated with the current game and round state
                    //
                    ManageRoundStateTasks();

                    //
                    // Evaluate and update the current game board state
                    //
                    _gameboard.UpdateGameboardState();

                    //
                    // Round Complete: Display the results
                    //
                    if (!_playingRound)
                    {
                        _gameView.DisplayCurrentGameStatus(_roundNumber, _playerXNumberOfWins, _playerONumberOfWins, _numberOfCatsGames);
                        _gameView.CurrentViewStateGame = ConsoleView.ViewStateGame.MainMenu;
                    }
                }
            }

            _gameView.DisplayClosingScreen();
        }

        /// <summary>
        /// manage each new game task based on the current game state
        /// </summary>
        private void ManageGameStateTasks()
        {
            switch (_gameView.CurrentViewStateGame)
            {
                case ConsoleView.ViewStateGame.MainMenu:
                    _gameView.DisplayMenuScreen();
                    break;
                case ConsoleView.ViewStateGame.GamePlay:
                    _gameboard.InitializeGameboard();
                    _playingRound = true;
                    break;
                case ConsoleView.ViewStateGame.Options:
                    // nested options menu functionality management
                    ManageOptionStateTasks();
                    break;
                case ConsoleView.ViewStateGame.CurrentGameStats:
                    _gameView.DisplayCurrentGameStatsScreen(_roundNumber, _playerXNumberOfWins, _playerONumberOfWins, _numberOfCatsGames);
                    _gameView.CurrentViewStateGame = ConsoleView.ViewStateGame.MainMenu;
                    break;
                case ConsoleView.ViewStateGame.HistoricStats:
                    // nested historic stats menu functionality managment
                    ManageHistoricStatsStateTasks();
                    break;
                case ConsoleView.ViewStateGame.Quit:
                    _playingGame = false;
                    break;
                default:
                    break;
            }
        }

        /// <summary>
        /// manage each Options tasks based on current Option state
        /// </summary>
        private void ManageOptionStateTasks()
        {
            switch (_gameView.CurrentViewStateOptions)
            {
                case ConsoleView.ViewStateOptions.OptionsMenu:
                    _gameView.DisplayOptionsScreen();
                    break;
                case ConsoleView.ViewStateOptions.SaveData:
                    //
                    // attempt to write to file
                    //
                    try
                    {
                        WritePlayerWinRecord();
                    }
                    //
                    // catch the first I/O error
                    //
                    catch (Exception ex)
                    {
                        _gameView.DisplayMessageBox(ex.Message);

                        _gameView.DisplayContinuePrompt();
                    }

                    _gameView.CurrentViewStateOptions = ConsoleView.ViewStateOptions.OptionsMenu;
                    break;
                case ConsoleView.ViewStateOptions.ClearData:
                    EraseSaves();
                    _gameView.CurrentViewStateOptions = ConsoleView.ViewStateOptions.OptionsMenu;
                    break;
                case ConsoleView.ViewStateOptions.ReturnToMenu:
                    _gameView.CurrentViewStateGame = ConsoleView.ViewStateGame.MainMenu;
                    _gameView.CurrentViewStateOptions = ConsoleView.ViewStateOptions.OptionsMenu;
                    break;
                default:
                    break;
            }
        }

        /// <summary>
        /// Read Player win history in saved txt file
        /// </summary>
        /// <returns>PlayerWinRecord</returns>
        private static List<PlayerWinsRecord> ReadPlayerHistory()
        {
            const char delineator = ','; // delineator in a CSV file

            List<PlayerWinsRecord> historicScores = new List<PlayerWinsRecord>();

            //
            // create lists to hold the historic score strings
            //
            List<string> historicScoresStringList = new List<string>();

            try
            {
                //
                // initialize a StreamReader object for reading from a file
                //
                StreamReader sReader = new StreamReader(DataStructure.DataFilePath);

                //
                // read all data from the data file
                //
                using (sReader)
                {
                    //
                    // keep reading lines of text until the end of the file is reached
                    //
                    while (!sReader.EndOfStream)
                    {
                        historicScoresStringList.Add(sReader.ReadLine());
                    }
                }
            }

            catch (Exception)
            {
                throw;
            }

            //
            // separate each line of text from the file into HistoricScore objects
            //
            if (historicScoresStringList != null)
            {
                //
                // separate lines into fields and build out the list of historic scores
                //
                foreach (string historicScore in historicScoresStringList)
                {

                    //
                    // use the Split method and the delineator on the array to separate each property into an array of properties
                    //
                    string[] fields = historicScore.Split(delineator);

                    //
                    // populate the historic scores list with HistoricScore objects
                    //
                    historicScores.Add(new PlayerWinsRecord() { PlayerInitial = fields[0], PlayerWins = Convert.ToInt32(fields[1]) });
                }
            }

            return historicScores;
        }

        /// <summary>
        /// Obtain and Save/Write a single player win record
        /// </summary>
        private void WritePlayerWinRecord()
        {
            int winNumber = 0;
            string playerInitials = "";

            // get player choice to save and look up corresponding win record
            winNumber = _gameView.DisplayGetPlayerWinSet(_playerXUnsavedWins, _playerOUnsavedWins);
            
            // quit out of writing win record if the user has chosen quit
            if (winNumber == -1)
            {
                return;
            }
            // throw an exception there isn't at least one win to record
            else if (winNumber < 1)
            {
                throw new PlayerWinsOutOfRangeException("A player must have at least one win to save win data!");
            }

            // get player initials
            playerInitials = _gameView.DisplayGetPlayerName();

            //
            // generate the record string for the data file using the 
            // StringBuilder class
            //

            StringBuilder sb = new StringBuilder();
            sb.Append(playerInitials + DataStructure.Delineator);
            sb.Append(winNumber);

            string newWinRecord = sb.ToString();

            try
            {
                //
                // initialize a StreamWriter object for writing to a file
                //
                StreamWriter sWriter = new StreamWriter(DataStructure.DataFilePath, true);

                //
                // read all data from the data file
                //
                using (sWriter)
                {
                    sWriter.WriteLine(newWinRecord);
                }

                if (winNumber == _playerXUnsavedWins)
                {
                    _playerXUnsavedWins = 0;
                    _gameView.DisplayContinuePrompt("Player X wins saved under '" + playerInitials + "'!");
                }
                else
                {
                    _playerOUnsavedWins = 0;
                    _gameView.DisplayContinuePrompt("Player O wins saved under '" + playerInitials + "'!");
                }
            }
            //
            // an I/O error was encountered
            //
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// write player history to text file
        /// </summary>
        /// <param name="playerWins">string that is the line to write to the text file</param>
        private static void EraseSaves()
        {
            try
            {
                //
                // initialize a StreamWriter object for writing to a file
                //
                StreamWriter sWriter = new StreamWriter(DataStructure.DataFilePath);

                //
                // read all data from the data file
                //
                using (sWriter)
                {
                    sWriter.Write(String.Empty);
                }
            }
            //
            // an I/O error was encountered
            //
            catch (Exception ex)
            {
                _gameView.DisplayErrorMessage(ex.Message);
            }

        }

        /// <summary>
        /// Find, add, order and return top five highest wins by player
        /// </summary>
        /// <param name=""></param>
        /// <returns></returns>
        private List<PlayerWinsRecord> FindTotalWins(List<PlayerWinsRecord> allWinTotals)
        {
            List<PlayerWinsRecord> totalWins = new List<PlayerWinsRecord>();
            int addedWins = 0;
            List<string> playerNames = new List<string>();

            // get a listing of all players
            foreach (var winRecord in allWinTotals)
            {
                if(!playerNames.Contains(winRecord.PlayerInitial))
                {
                    playerNames.Add(winRecord.PlayerInitial);
                }
            }

            // get total wins per player and add a record for each to totalWins
            foreach (var player in playerNames)
            {
                addedWins = 0;
                foreach (var winRecord in allWinTotals)
                {
                    if(player == winRecord.PlayerInitial)
                    {
                        addedWins += winRecord.PlayerWins;
                    }
                }
                totalWins.Add(new PlayerWinsRecord() { PlayerInitial = player, PlayerWins = addedWins });
            }

            return totalWins;
        }

        /// <summary>
        /// Find and return top five win records in a list
        /// </summary>
        /// <param name="totalWins"></param>
        /// <returns></returns>
        private List<PlayerWinsRecord> FindTopWins(List<PlayerWinsRecord> totalWins)
        {
            List<PlayerWinsRecord> topWins = totalWins;

            topWins.Sort();
            topWins.Reverse();
            while (topWins.Count > 5)
            {
                topWins.RemoveAt(5);
            }

            return topWins;
        }

        /// <summary>
        /// Find total win amount for a specific player or throws an exception if no player wins discovered
        /// </summary>
        /// <param name="totalWins"></param>
        /// <param name="playerName"></param>
        /// <returns></returns>
        private PlayerWinsRecord FindPlayerWins(List<PlayerWinsRecord> totalWins, string playerName)
        {
            PlayerWinsRecord playerWins = new PlayerWinsRecord() { PlayerInitial = playerName, PlayerWins = 0 };

            foreach (var record in totalWins)
            {
                if (record.PlayerInitial == playerWins.PlayerInitial)
                {
                    playerWins.PlayerWins = record.PlayerWins;
                    break;
                }
                else
                {
                    playerWins.PlayerWins = -1;
                }
            }

            if (playerWins.PlayerWins == -1)
            {
                throw new PlayerWinsOutOfRangeException("A player must have at least one win to view win data!");
            }

            return playerWins;
        }

        /// <summary>
        /// Process and retrieve chosen player historic win records
        /// </summary>
        /// <param name="playerInitials"></param>
        private void ProcessFilteredHistoricStats(string playerInitials)
        {
            // leave the method immediately if 'q' is the input (allow for quitting)
            if (playerInitials.ToUpper() == "Q")
            {
                return;
            }
            else
            {
                //create historic stats listing from data, find win totals by player, isolate by selected initials
                List<PlayerWinsRecord> historicStats = new List<PlayerWinsRecord>();
                historicStats = ReadPlayerHistory();
                historicStats = FindTotalWins(historicStats);
                PlayerWinsRecord playerWinTotal = FindPlayerWins(historicStats, playerInitials);

                _gameView.DisplayContinuePrompt(playerWinTotal.PlayerInitial + " currently has a saved win record of " + playerWinTotal.PlayerWins.ToString() + "!");
            }
        }

        /// <summary>
        /// manage each Historic Stats tasks based on current Historic Stats state
        /// </summary>
        private void ManageHistoricStatsStateTasks()
        {
            switch (_gameView.CurrentViewStateHistoricStats)
            {
                case ConsoleView.HistoricStatsState.HistoricStatsMenu:
                    _gameView.DisplayHistoricGameStatsScreen();
                    break;
                case ConsoleView.HistoricStatsState.HighScores:
                    // historic scores will be stored internally in the application as a list of objects
                    List<PlayerWinsRecord> historicScores = new List<PlayerWinsRecord>();

                    // attempt to read from the data file and create top scores list
                    try
                    {
                        historicScores = ReadPlayerHistory();
                        historicScores = FindTotalWins(historicScores);
                        historicScores = FindTopWins(historicScores);

                        _gameView.DisplayHistoricScores(historicScores);
                    }
                    //
                    // catch the first I/O error
                    //
                    catch (Exception ex)
                    {
                        _gameView.DisplayErrorMessage(ex.Message);
                    }
                    _gameView.CurrentViewStateHistoricStats = ConsoleView.HistoricStatsState.HistoricStatsMenu;
                    break;
                case ConsoleView.HistoricStatsState.Filtering:
                    //TODO create and add method in controller for filtering data, taking input from view method
                    //TODO create filtering input method in view (seperate screen) 
                    try
                    {
                        ProcessFilteredHistoricStats(_gameView.DisplayGetPlayerInfoToRetrieve());
                    }
                    //
                    // catch the first I/O error
                    //
                    catch (Exception ex)
                    {
                        _gameView.DisplayErrorMessage(ex.Message);
                    }
                    _gameView.CurrentViewStateHistoricStats = ConsoleView.HistoricStatsState.HistoricStatsMenu;
                    break;
                case ConsoleView.HistoricStatsState.ReturnToMenu:
                    _gameView.CurrentViewStateGame = ConsoleView.ViewStateGame.MainMenu;
                    _gameView.CurrentViewStateHistoricStats = ConsoleView.HistoricStatsState.HistoricStatsMenu;
                    break;
                default:
                    break;
            }
        }

        /// <summary>
        /// manage each new round task based on the current round state
        /// </summary>
        private void ManageRoundStateTasks()
        {
            switch (_gameView.CurrentViewStateInRound)
            {
                case ConsoleView.ViewStateInRound.RoundEnabled:
                    if (_gameboard.CurrentRoundState != Gameboard.GameboardState.NewRound)
                    {
                        _gameView.DisplayGameArea();
                    }
                    switch (_gameboard.CurrentRoundState)
                    {
                        case Gameboard.GameboardState.NewRound:

                            _gameView.InProgressPosition = new GameboardPosition(-1, -1, -1);
                            _roundNumber++;
                            SetUpTurnOrder();
                            break;

                        case Gameboard.GameboardState.PlayerXTurn:
                            ManagePlayerTurn(Gameboard.PlayerPiece.X);
                            break;

                        case Gameboard.GameboardState.PlayerOTurn:
                            ManagePlayerTurn(Gameboard.PlayerPiece.O);
                            break;

                        case Gameboard.GameboardState.PlayerXWin:
                            _playerXNumberOfWins++;
                            _playerXUnsavedWins++;
                            _playingRound = false;
                            break;

                        case Gameboard.GameboardState.PlayerOWin:
                            _playerONumberOfWins++;
                            _playerOUnsavedWins++;
                            _playingRound = false;
                            break;

                        case Gameboard.GameboardState.CatsGame:
                            _numberOfCatsGames++;
                            _playingRound = false;
                            break;

                        default:
                            break;
                    }
                    break;

                case ConsoleView.ViewStateInRound.PlayerUsedMaxAttempts:
                    _gameView.DisplayMaxAttemptsReachedScreen();
                    _playingRound = false;
                    _gameView.CurrentViewStateInRound = ConsoleView.ViewStateInRound.RoundEnabled;
                    break;
                case ConsoleView.ViewStateInRound.PlayerQuit:
                    _playingRound = false;
                    _gameView.CurrentViewStateInRound = ConsoleView.ViewStateInRound.RoundEnabled;
                    break;
                default:
                    break;
            }

            
        }

        /// <summary>
        /// Obtain and implement which player will go first in a given round of play
        /// </summary>
        private void SetUpTurnOrder()
        {
            ConsoleView.PlayerSelectionChoice playerChoice = _gameView.DisplayChoosePlayerToGoFirstScreen();
            switch (playerChoice)
            {
                case ConsoleView.PlayerSelectionChoice.PlayerXFirst:
                    _gameboard.CurrentRoundState = Gameboard.GameboardState.PlayerXTurn;
                    _movesFirst = Player.PlayerX;
                    break;
                case ConsoleView.PlayerSelectionChoice.PlayerOFirst:
                    _gameboard.CurrentRoundState = Gameboard.GameboardState.PlayerOTurn;
                    _movesFirst = Player.PlayerO;
                    break;
                case ConsoleView.PlayerSelectionChoice.OppositeOfLastRound:
                    if (_movesFirst == Player.None)
                    {
                        _gameView.DisplayNoPreviousFirstPlayerMessage();
                        _gameboard.CurrentRoundState = Gameboard.GameboardState.PlayerXTurn;
                        _movesFirst = Player.PlayerX;
                    }
                    else if (_movesFirst == Player.PlayerX)
                    {
                        _gameboard.CurrentRoundState = Gameboard.GameboardState.PlayerOTurn;
                        _movesFirst = Player.PlayerO;
                    }
                    else
                    {
                        _gameboard.CurrentRoundState = Gameboard.GameboardState.PlayerXTurn;
                        _movesFirst = Player.PlayerX;
                    }
                    break;
                case ConsoleView.PlayerSelectionChoice.ComputerDecided:
                    _movesFirst = ChooseRandomPlayer();
                    if (_movesFirst == Player.PlayerO)
                    {
                        _gameboard.CurrentRoundState = Gameboard.GameboardState.PlayerOTurn;
                    }
                    else
                    {
                        _gameboard.CurrentRoundState = Gameboard.GameboardState.PlayerXTurn;
                    }
                    break;
                default:
                    break;
            }
        }

        /// <summary>
        /// picks a random player
        /// </summary>
        /// <returns>Player</returns>
        private Player ChooseRandomPlayer()
        {
            Player chosenPlayer = Player.None;

            // create and pick player based on random number
            // I'm hoping seed issues won't be a problem because enough time should pass
            // between uses of the method
            Random randomNum = new Random();
            if (randomNum.Next(0, 2) == 0)
            {
                chosenPlayer = Player.PlayerO;
            }
            else
            {
                chosenPlayer = Player.PlayerX;
            }

            return chosenPlayer;
        }

        /// <summary>
        /// Attempt to get a valid player move. 
        /// If the player chooses a location that is taken, the CurrentRoundState remains unchanged,
        /// the player is given a message indicating so, and the game loop is cycled to allow the player
        /// to make a new choice.
        /// </summary>
        /// <param name="currentPlayerPiece">identify as either the X or O player</param>
        private void ManagePlayerTurn(Gameboard.PlayerPiece currentPlayerPiece)
        {
            GameboardPosition gameboardPosition = _gameView.GetPlayerPositionChoice();

            if (_gameView.CurrentViewStateInRound == ConsoleView.ViewStateInRound.RoundEnabled)
            {
                //
                // player chose an open position on the game board, add it to the game board
                //
                if (_gameboard.GameboardPositionAvailable(gameboardPosition))
                {
                    _gameboard.SetPlayerPiece(gameboardPosition, currentPlayerPiece);
                }
                //
                // player chose a taken position on the game board
                //
                else
                {
                    _gameView.DisplayGamePositionChoiceNotAvailableScreen();
                }
            }
        }

        #endregion
    }
}
