﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodingActivity_TicTacToe_ConsoleGame.Controller
{
    public class PlayerInitialOutOfRangeException : Exception
    {
        public PlayerInitialOutOfRangeException(string message) : base(message)
        {
        }
    }

    public class PlayerWinsOutOfRangeException : Exception
    {
        public PlayerWinsOutOfRangeException(string message) : base(message)
        {
        }
    }    

    
}
